package com.oanda.v20.transaction;

import com.oanda.v20.account.AccountID;
import com.oanda.v20.primitives.DateTime;

/**
 * The base Transaction specification. Specifies properties that are common
 * between all Transaction.
 */
public interface Transaction {

    /**
     * Get the Transaction type.
     * <p>
     * The type of the Transaction
     * <p>
     * @return the Transaction type
     * @see TransactionType
     */
    public TransactionType getType();

    /**
     * Get the Transaction ID
     * <p>
     * The Transaction's Identifier.
     * <p>
     * @return the Transaction ID
     * @see TransactionID
     */
    public TransactionID getId();

    /**
     * Set the Transaction ID
     * <p>
     * The Transaction's Identifier.
     * <p>
     * @param id the Transaction ID as a TransactionID
     * @return {@link Transaction Transaction}
     * @see TransactionID
     */
    public Transaction setId(TransactionID id);
    /**
     * Set the Transaction ID
     * <p>
     * The Transaction's Identifier.
     * <p>
     * @param id the Transaction ID as a String
     * @return {@link Transaction Transaction}
     * @see TransactionID
     */
    public Transaction setId(String id);

    /**
     * Get the Time
     * <p>
     * The date/time when the Transaction was created.
     * <p>
     * @return the Time
     * @see DateTime
     */
    public DateTime getTime();

    /**
     * Set the Time
     * <p>
     * The date/time when the Transaction was created.
     * <p>
     * @param time the Time as a DateTime
     * @return {@link Transaction Transaction}
     * @see DateTime
     */
    public Transaction setTime(DateTime time);
    /**
     * Set the Time
     * <p>
     * The date/time when the Transaction was created.
     * <p>
     * @param time the Time as a String
     * @return {@link Transaction Transaction}
     * @see DateTime
     */
    public Transaction setTime(String time);

    /**
     * Get the User ID
     * <p>
     * The ID of the user that initiated the creation of the Transaction.
     * <p>
     * @return the User ID
     */
    public Long getUserID();

    /**
     * Set the User ID
     * <p>
     * The ID of the user that initiated the creation of the Transaction.
     * <p>
     * @param userID the User ID as a Long
     * @return {@link Transaction Transaction}
     */
    public Transaction setUserID(Long userID);

    /**
     * Get the Account ID
     * <p>
     * The ID of the Account the Transaction was created for.
     * <p>
     * @return the Account ID
     * @see AccountID
     */
    public AccountID getAccountID();

    /**
     * Set the Account ID
     * <p>
     * The ID of the Account the Transaction was created for.
     * <p>
     * @param accountID the Account ID as an AccountID
     * @return {@link Transaction Transaction}
     * @see AccountID
     */
    public Transaction setAccountID(AccountID accountID);
    /**
     * Set the Account ID
     * <p>
     * The ID of the Account the Transaction was created for.
     * <p>
     * @param accountID the Account ID as a String
     * @return {@link Transaction Transaction}
     * @see AccountID
     */
    public Transaction setAccountID(String accountID);

    /**
     * Get the Transaction Batch ID
     * <p>
     * The ID of the "batch" that the Transaction belongs to. Transactions in
     * the same batch are applied to the Account simultaneously.
     * <p>
     * @return the Transaction Batch ID
     * @see TransactionID
     */
    public TransactionID getBatchID();

    /**
     * Set the Transaction Batch ID
     * <p>
     * The ID of the "batch" that the Transaction belongs to. Transactions in
     * the same batch are applied to the Account simultaneously.
     * <p>
     * @param batchID the Transaction Batch ID as a TransactionID
     * @return {@link Transaction Transaction}
     * @see TransactionID
     */
    public Transaction setBatchID(TransactionID batchID);
    /**
     * Set the Transaction Batch ID
     * <p>
     * The ID of the "batch" that the Transaction belongs to. Transactions in
     * the same batch are applied to the Account simultaneously.
     * <p>
     * @param batchID the Transaction Batch ID as a String
     * @return {@link Transaction Transaction}
     * @see TransactionID
     */
    public Transaction setBatchID(String batchID);

    /**
     * Get the Request ID
     * <p>
     * The Request ID of the request which generated the transaction.
     * <p>
     * @return the Request ID
     * @see RequestID
     */
    public RequestID getRequestID();

    /**
     * Set the Request ID
     * <p>
     * The Request ID of the request which generated the transaction.
     * <p>
     * @param requestID the Request ID as a RequestID
     * @return {@link Transaction Transaction}
     * @see RequestID
     */
    public Transaction setRequestID(RequestID requestID);
    /**
     * Set the Request ID
     * <p>
     * The Request ID of the request which generated the transaction.
     * <p>
     * @param requestID the Request ID as a String
     * @return {@link Transaction Transaction}
     * @see RequestID
     */
    public Transaction setRequestID(String requestID);
}
